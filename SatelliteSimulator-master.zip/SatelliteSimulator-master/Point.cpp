#include <Point.h>

Point::Point()
{

}

Point::~Point()
{

}
