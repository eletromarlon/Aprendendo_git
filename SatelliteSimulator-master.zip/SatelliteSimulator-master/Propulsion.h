#ifndef PROPULSION_H
#define PROPULSION_H


class Propulsion
{
public:
    Propulsion();
    ~Propulsion();
};

#endif // PROPULSION_H
