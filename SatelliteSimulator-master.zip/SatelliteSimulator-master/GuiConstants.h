#ifndef GUICONSTANTS
#define GUICONSTANTS

namespace GuiConstants
{

    //Monitor bottom bar height
    static const int monitorH = 100;

    // Frames per second
    static const int fps = 60;
}

#endif // GUICONSTANTS

